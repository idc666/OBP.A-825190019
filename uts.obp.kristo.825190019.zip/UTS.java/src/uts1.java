public class uts1 {
   public String pilih;

   public int panjang;
   public int tinggi;
   public int lebar;
   public double sisi;
   double d1;
   double d2;


    double calculateLayang() {
        return sisi * sisi * sisi * sisi;
    }
    double hiitungluasLayang() {
        return 0.5 * d1 * d2;}
}

//System.out.print("Sisi= ");
        //float sisi = s.nextInt();

