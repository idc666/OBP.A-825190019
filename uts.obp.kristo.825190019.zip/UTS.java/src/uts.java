import java.util.Scanner;
public class uts {
    public static void main(String[] Args) {
        Scanner s = new Scanner(System.in);

            System.out.println("Pilih banguan ruang");
            System.out.println("1.Persegi ");
            System.out.println("2.Segitiga  ");
            System.out.println("3.Persegi Panjang  ");
            System.out.println("4.Lingkaran  ");
            System.out.println("5.Layang - layang  ");
            System.out.print("Pilihan anda = ");
            int pilih = s.nextInt();

        if (pilih == 1) {
            System.out.println("Anda Memilih Persegi");
            System.out.print("Sisi = ");
            float sisi = s.nextInt();
            float Keliling = 4 * sisi;
            float Luas = sisi * sisi;
            System.out.println("Keliling = " + Keliling);
            System.out.print("Luas = " + Luas);


        }
        if (pilih == 2) {
            System.out.println("Anda Memilih Segitiga");
            System.out.print("alas = ");
            float alas = s.nextInt();
            System.out.print("tinggi = ");
            float tinggi = s.nextInt();
            System.out.print("a = ");
            float a = s.nextInt();
            System.out.print("b = ");
            float b = s.nextInt();
            System.out.print("c = ");
            float c = s.nextInt();
            double Luas = (0.5 * (alas * tinggi));
            float Keliling = a + b + c;
            System.out.println("Keliling = " + Keliling);
            System.out.print("Luas = " + Luas);

        }
        if (pilih == 3) {
            System.out.println("Anda Memilih Persegi Panjang ");
            System.out.print("Panjang = ");
            float panjang = s.nextInt();
            System.out.print("Lebar = ");
            float lebar = s.nextInt();

            float Luas = panjang * lebar;
            float keliling = 2 * (panjang+lebar);
            System.out.println("Keliling = " + keliling);
            System.out.print("Luas = " + Luas);
        }
        if (pilih == 4 ) {
            System.out.println("Anda Memilih Lingkaran ");
            double phi=22/7;
            System.out.print("Jari - jari = ");
            float r = s.nextInt();
            System.out.print("Diameter = ");
            float d = s.nextInt();

            float Keliling = (float) (phi*d);
            double Luas = phi*r*r;
            System.out.println("Keliling = " + Keliling);
            System.out.print("Luas = " + Luas);

        }
        if (pilih == 5 ) {
            uts1 l = new uts1();
            l.sisi=4;
            l.d1=3;
            l.d2=5;
            System.out.println("Anda Memilih Layang-layang ");
            System.out.println("Keliling = " + l.calculateLayang());
            System.out.println("Luas = " + l.hiitungluasLayang());
        }



        
        }
}
